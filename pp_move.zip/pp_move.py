#!/usr/bin/env python3

version='1.1.12'
"""
pp_move.py Ver 1.1.12 2018-11-21
to Public Domain from Charlie Howard

PURPOSE: rejoin Footnotes, move Illustrations and Sidenotes to paragraph breaks.

GENERAL LOGIC FLOW:
Initialize globals
Get input fileid and any options from command line; use defaults if none
Read the file into a List
Temporarily replace end-of-line right brackets that are not the ends of tags
Rejoin continuation footnotes unless suppressed by command-line option
Add opening asterisks as needed to any [Ill and [Side that should be moved
Find and move *[Illustration and *[Sidenote to the nearest available paragraph
    break (ABOVE for Sidenotes, above OR below for Illustrations) that is
    not within some other tag; remove the asterisk; if there was an
    incorrect top-of-page blank line, remove it; do not move mid-paragraph
    *[Sidenotes (they are not followed by blank lines)
Restore the temporarily-replaced right brackets
Flag invalid characters (ascii 128-159) with [** notes]
Prepare summary-of-results message, put it at the front of the List
Write the List to the new file

HISTORY:
1.1.12: try UTF-8 first, then Latin-1, in case it IS a utf8 file
1.1.11: warn if unequal #'s of brackets and/or parentheses
1.1.10: cosmetic: put everything into functions, so main is just flow control
1.1.9: never released
1.1.8: fix: continuation footnote immediately followed by another foootnote
1.1.7: cosmetic
1.1.6: new: flags the invalid characters with [** notes]
1.1.5: fix: tag ending on last line; new: bypasses invalid characters in range 128-159
1.1.4: fix: unexpected blank lines
1.1.3: never released
1.1.2: new: supports moving Illustrations DOWN as well as UP
1.1.1: initial release
"""

import os, sys, time

#globals
#user options:
fnsw=True       #rejoin continuation footnotes
snsw=False      #rejoin multi-line sidenotes

#user may modify:
outlabel='_moved'
outid='moved.txt'
inid='x.txt'
outpath=''

#other globals
imoved=0        #counters to show results
smoved=0
fmoved=0
nembeds=0
nbdeleted=0
nskipped=0
badchars=False
eol=os.linesep  #find what the environment uses for end-of-line
zr=''          #placeholder to make certain right brackets invisible; char is ascii 21
sep='-----File:'
bp='[Blank Page]'
taglist=('[Footnote', '*[Footnote', '[Illustration', '*[Illustration', '[Sidenote', '*[Sidenote')
rmsg=''
enc=''
text=''
text1=''

#functions called by other functions
def issep(i):   return text[i][:len(sep)]==sep                #is 'i' a separator line
def isblank(i): return (len(text[i]))==0                      #is 'i' a blank line
def isbp(i):    return(text[i][:len(bp)])==bp                 #is 'i' a [Blank Page]
def istag(i):   return any(tag in text[i] for tag in taglist) #does 'i' contain a tag?

#is bracket at linend end of a tag or of something else
def istagend(tagstart):
    wk=text[tagstart]
    res=0   #can return 0 (not a bracket); 1 (not tagend); 2 (yes tagend)
    if wk[-1] == ']':
        sotsw=wk[0]=='[' or wk[0:2]=='*['
        nl=wk.count('[')
        nr=wk.count(']')
        if sotsw:
            if nl == nr: res=2
            else: res=1
        elif nl==nr: res=1
        else: res=2
    return res

#find next occurence of asterisked 'tag'
def findstart(tag,tagstart):
    atag='*'+tag
    latag=len(atag)
    for i in range(tagstart,len(text)):
        if text[i][:latag]==atag:
            return i
    return -1

#find next occurence of 'tag' with/without asterisk
def findstartf(tag,tagstart):
    for i in range(tagstart,len(text)):
        if text[i].find(tag) >=0: return i
    return -1

#find where tag ends ']'
def findend(tag,tagstart):
    for i in range(tagstart,len(text)-1):
        if text[i][-1:]==']' or text[i][-2:]==']*':
            #ignore closing ] of notes or text
            if istagend(i)==2 or issep(i+1) or isblank(i+1) or istag(i+1):
                if  tag=='[Footnote' or issep(i+1) or (i<len(text)-1 and \
                   (not (text[i+2][:len(tag)]==tag or text[i+2][:len(tag)+1]=='*'+tag))):
                    return i
    return -1

#find closest available blank line ABOVE 'tagstart'
def findblank(tag,tagstart):
    inside=False
    fnsw=False
    for i in range(tagstart-1,0,-1):
        wk=text[i]
        if wk.find(tag)>=0: return -1         #don't go up past same tag type
        if wk[-1:]==']' or wk[-2:-1]==']*':
            inside=True                            #see if inside a markup
        if inside:  #recheck on same line, as markup could be just one line long
            if wk[:1]=='[' or wk[:2]=='*[':
                inside=False                       #see if still inside a markup
                fnsw=wk.find('[Footnote')>=0  #if it was a footnote, the blank line above it doesn't count
                if fnsw:
                    fnsw=not text[i-2][-1:]=='.'    #if end of sentence, this is an ok position to use
        elif isblank(i):
            if fnsw: fnsw=False
            else: return i

#find closest available blank line BELOW 'tagstart'
def findblankdown(tag,tagstart):
    tend=findend(tag,tagstart)      #first, see where this one ends
    if tend>=tagstart:
        for i in range(tend+2,len(text)):   #don't consider blank line below this tag
            wk=text[i]
            #if wk.find(tag)=0: return -1   #don't go down past same tag type
            if istag(i): return -1          #don't go past any following tag
            if isblank(i) and (text[i+1].find(tag)>=0 or not istag(i+1)):
                return i                    #found a blank line, return it's position

#see if a mid-paragraph *[Sidenote should remain where it is
def isembedded(tagstart, tagend, prevstart, prevend):
    global nembeds  #count embedded (non-movable) Sidenotes
    sw1=istag(tagstart-1)     #is prev line a tag
    sw2=issep(tagstart-1)     #is prev line a separator
    sw3=isblank(tagstart-1)   #is prev line blank
    sw4=isblank(tagend+1)     #is next line blank
    res= sw1 or not sw4 or not(sw2 or not sw3)
    if res: nembeds+=1
    return res

#primary processing to move *[Illustrations and non-embedded *[Sidenotes
def move():
    global text, imoved, smoved, nbdeleted
    itag='[Illustration'
    stag='[Sidenote'
    tagstart=1
    nextstart=2
    prevstart=-1
    prevend=-1
    nexti=0
    nexts=0
    
    while tagstart>0:
        currstart=tagstart
        nextstart=tagstart+1    #just in case it isn't updated later on
        if nexts>=0: nexts=findstart(stag,tagstart)
        if nexti>=0: nexti=findstart(itag,tagstart)
        if nexti>0:
            if nexti<nexts or nexts<0:
                tagstart=nexti
                tag=itag
                ssw=False
        if nexts>0:
            if nexts<nexti or nexti<0:
                tagstart=nexts
                tag=stag
                ssw=True
        if nexti<0 and nexts<0:
            return
        if tagstart>0:
            currstart=tagstart
            nextstart=tagstart+1
            tagend=findend(tag,tagstart)    #always right bracket
            updsw=True                      #update the pointers at end of this iter
            if tagend>=tagstart:
                taglen=tagend-tagstart+1    #to calculate next starting point
                if isblank(tagstart-1) and issep(tagstart-2):     #formatting error; correct it
                    del text[tagstart-1]
                    tagstart-=1
                    tagend-=1
                    currstart-=1
                    nextstart-=1
                    nexts-=1
                    nbdeleted+=1
                oksw=True
                if ssw:                     #check for non-movable sidenotes
                    oksw= not isembedded(tagstart, tagend, prevstart, prevend)
                    
                if oksw:
                    tagend+=1
                    targetup=findblank(tag,tagstart)       #look for preceding blank
                    if tag==stag:                          #Sidenotes only move up
                        if targetup>0: target=targetup
                        else: target=-1
                    else:                                  #illos can move up or down
                        targetdown=findblankdown(tag,tagstart) #look for next blank
                        if targetup>0:                          #decide which is closest
                            if targetdown<0:
                                target=targetup
                            elif (tagstart-targetup)<(targetdown-tagend):
                                target=targetup
                            else:
                                target=targetdown
                        elif targetdown>0: target=targetdown
                        else: target=-1
                    
                    if target>0:
                        if target==targetup and (text[target+1][:len(tag)]==tag or
                                                   text[target+1][1:len(tag)]==tag):  #don't move up above earlier same tag
                            j=findend(tag,target)
                            if j>=0:
                                target=j+1
                        temp=text[tagstart:tagend]          #store line(s) to be moved
                        temp[0]=temp[0][1:]                 #remove the asterisk
                        if len(text[tagend])==0:            #remove trailing blank line
                               tagend+=1
                        if target<tagstart:                 #if moving up, first
                            del text[tagstart:tagend]       #cut the original tag lines
                        text.insert(target,'')              #begin the move with blank line
                        if not ssw: imoved+=1               #count # of moves by tag
                        else: smoved+=1
                        for j in range(len(temp)):          #paste the tag lines
                            text.insert(target+j+1,temp[j])
                        if target>tagstart:                 #if moving down,
                            del text[tagstart:tagend]       #cut orig lines afterwards
                        prevstart=target
                        prevend=prevstart+taglen-1
                        tagstart=target+taglen
                        updsw=False                         #pointer update complete
                    
            if updsw:                                       #update pointers for next iter?
                prevstart=tagstart
                prevend=tagend
                tagstart=tagend+1

#primary processing to rejoin continuation footnotes when ]* and *[Footnote match up
def footnotes():
    global text, fmoved
    tagstart=1
    tagend=-1
    ftag='[Footnote'
    ftaglen=len(ftag)
    while tagstart>0:
        fsw=False
        currstart=tagstart
        nextf=findstartf(ftag,tagstart)
        if nextf<0: break
        if nextf>=tagstart:
            tagstart=nextf
            tagend=findend(ftag,tagstart)
            if text[nextf][:ftaglen]==ftag and tagend>=tagstart: #want a new fn, not a continuation
                if text[tagend][-2:]==']*':        #new, has a continuation
                    nextf=findstartf(ftag,tagend+1)              #look for next footnote
                    nextfend=findend(ftag,nextf)                 #and where it ends
                    if nextf>tagend and nextfend>=nextf:
                        if text[nextf][0:ftaglen+1]=='*[Footnote':  #found continuation
                            #do the rejoin:
                            #1. remove the * at end of tagend line
                            text[tagend]=text[tagend][:-2]
                            #2. copy continuation line(s) to temp list
                            temp=text[nextf:nextfend+1]
                            #3. remove '*[Footnote: ' from first item in temp
                            temp[0]=temp[0][ftaglen+3:]
                            #4. delete original continuation lines, including leading blank
                            del text[nextf:nextfend+1]
                            if isblank(nextf-1): del text[nextf-1]   #leading blank
                            #5. insert temp line(s) after tagend line
                            for j in range(len(temp)):
                                text.insert(tagend+j+1,temp[j])
                            #leave 'tagstart' -> main footnote, in case there are more continuations
                            fsw=True        #show a continuation was made
                            fmoved+=1       #bump counter
                            
            if not fsw: tagstart=tagend+1   #has no continuation, or mis-formatted


#initial and final functions

#get fileid's and options from command line if present, or use defaults
def getfileids():
    global inid, outid, outpath, fnsw
    if len(sys.argv)>1:
        inid=sys.argv[1]    #use cmd-line filename if given
        inpath=os.path.dirname(inid)
    else: inid="x.txt"      #use default name if none given
    outpath=os.path.dirname(inid)
    outid=os.path.join(outpath, os.path.split(os.path.splitext(inid)[0])[1]+ \
                       outlabel+os.path.splitext(inid)[1])
    if len(sys.argv)>2:     #check for option to not rejoin footnotes
        fnsw=sys.argv[2] != '-f' and sys.argv[2] != '/f'
    if os.path.exists(outid): os.remove(outid)

#open input file, find file encoding, read & store the file
def getfile():
    global text,enc
    if not os.path.exists(inid): return(2)  #file not found
    try:
      inh=open(inid, 'r', newline='', encoding='UTF-8')
      text=[x.rstrip() for x in inh.readlines()]
      enc="UTF-8"           #need this to write the output file properly
    except UnicodeDecodeError:
      inh=open(inid, 'r', newline='', encoding='Latin-1')
      text=[x.rstrip() for x in inh.readlines()]
      enc="Latin-1"
    except FileNotFoundError: return(2)
    except: return(1)       #unknown error
    return(0)               #file opened successfully

#temporarily replace right brackets that are not marker-ends with
#the zr char so that they will be ignored when moving things around
def zapnotes():
    global text
    j=len(text)
    for i in range(len(text)):
        if len(text[i])>4:
            if text[i][-1:]==']':
                if istagend(i)==1:
                    text[i]=text[i][:-1]+zr

#restore right brackets
def unzapnotes():
    global text
    text=[s.replace(zr,']') for s in text]

#add missing *'s where needed by mid-paragraph [Ill's and [Side's;
#delete erroneous blank lines between top-of-page and *[Illustration or *[Sidenote
def precheck(tag):
    global text, nbdeleted
    i=2
    tagend=i
    while i<len(text)-4:                 #leave back/forward cushions
        if text[i][:len(tag)]==tag:      #find each left-bracket at start of a line
            skipsw=False
            if tag=='[Illustration':     #try to ignore some full-page illustrations
                tagend=findend(tag,i)
                if issep(tagend+1) and (issep(i-1) or (isblank(i-1) and issep(i-2))):
                    if (isbp(tagend+2) and issep(tagend+3) and isblank(tagend+4)) or \
                       isblank(tagend+2) or issep(tagend+2):
                        skipsw=True     #full-page illo that should be left as-is
                    elif isblank(i-1) and issep(i-2):
                        del text[i-1]
                        i-=1
                        nbdeleted+=1
                        tagend-=1
                elif isblank(tagend+1) and len(text[tagend+2])>0 and \
                     text[tagend+2][0].islower():
                    if isblank(i-1):
                        del text[i-1]
                        nbdeleted+=1
                        i-=1
                        tagend-=1
            if not skipsw and not isblank(i-1):
                text[i]='*'+text[i]
        if i<tagend: i=tagend+1
        else: i+=1

#Replace a set of multiple sub strings with a new string in main string.
def replaceMultiple(mainString, toBeReplaces, newstring=''): #not using 3rd parm
    global badchars
    # Iterate over the strings to be replaced
    for elem in toBeReplaces :
        # Check if string is in the main string
        if elem in mainString :
            badchars=True
            # Replace the string
            mainString = mainString.replace(elem, elem+'[** bad character: '+hex(ord(elem))+']')
    
    return  mainString

#look for invalid characters (in range 128-159)
def ckbadchars():
    global text1
    u=[chr(128)]                                #create list of invalid characters
    for i in range(129,160):
        u.append(chr(i))
    text1=(replaceMultiple(eol.join(text),u))   #replace them with a warning [**note]

#Create summary report and put it at the top of what will become the result file
def report():
    global text1
    rmsge=''
    #count number of unhandled starred tags (some may be deliberate embedded sidenotes)
    nerr=sum(star in textline for star in [']*', '*['] for textline in text)
    rmsgc=''
    if badchars:
        rmsgc='Invalid characters (ascii 128-159) have been [** noted]'
    if nerr>0 or badchars:
        #rmsge= eol+eol+'    ***** ALSO CHECK: *****'+eol
        if nerr>0: rmsge+=eol+ format(nerr-nembeds, '13d') + \
                      ' unprocessed  ]*  and  *[  remain in file'
        if badchars: rmsge+=eol+rmsgc

    fnmsg='Footnote processing skipped at your request.'
    if fnsw:
        qtyword='now' if fmoved>0 else 'still'
        fnmsg='Rejoined ' + format(fmoved, '4d') + \
                    ' footnotes, ' + qtyword + ' have ' + \
                    str(sum('[Footnote' in s for s in text))+'.'

    emmsg=''
    if nembeds>0: emmsg=eol+'Skipped '+format(nembeds, '5d')+ \
           ' embedded sidenotes.'

    bdeletedmsg=''
    if nbdeleted>0: bdeletedmsg=eol+'Deleted'+format(nbdeleted, '6d')+ \
           ' top-of-page blank lines above *[Ill and/or *[Side'

    emsgbracket=''      #check for unequal # of brackets and parentheses
    if text1.count('[') != text1.count (']'):
        emsgbracket=eol+'Found an unequal number of left and right square brackets.'
    if text1.count('(') != text1.count (')'):
        emsgbracket=emsgbracket+eol+'Found an unequal number of left and right parentheses.'
    rmsg=fnmsg+eol+'Moved ' + format(imoved, '7d') + ' of ' + \
          format(sum('[Ill' in s for s in text), '4d') + \
           ' illustrations.'+eol+'Moved ' + format(smoved, '7d') + \
           ' of ' + format(sum('[Sid' in s for s in text), '4d') + \
           ' sidenotes.' + emmsg + bdeletedmsg + rmsge + emsgbracket

    #Summary report complete; put it at top of new text file
    text1='[** pp_move ver. '+version + ' results:'+eol+rmsg+']'+eol+eol+text1

#create the result file
def writefile(): 
    outh=open(outid,'w', newline='', encoding=enc).write(text1)


########## main #############
def main():
    mainsw=__name__ == '__main__'
    stime=time.perf_counter()   #for development, to measure performance
    if mainsw:
        print ('Starting pp_move')  #these messages only are seen during development
    getfileids()
    rcode=getfile()
    if rcode != 0:
        print('Error',str(rcode), 'trying to open',inid)
        return(1)
    if mainsw:
        print('File \''+inid+'\' contains','{:,}'.format(len(text),'d'),'lines')
    zapnotes()

    #default is to rejoin continuation footnotes, unless -f cmd line sw was found
    if fnsw:
        if mainsw:
            print ('Processing',str(sum('[Footnote' in s for s in text)),'Footnotes')
        footnotes()             #rejoin continuation footnotes

    precheck('[Illustration')   #find unstarred illos that may need moving
    precheck('[Sidenote')       #find unstarred sn's that may need moving

    if mainsw:
        print ('Processing',str(sum('[Illustration' in s for s in text)), \
           'illustrations and',str(sum('[Sidenote' in s for s in text)),'sidenotes')

    move()          #find and move the Illustrations and Sidenotes that are mid-paragraph
    unzapnotes()    #restore the 'invisible' right-brackets
    ckbadchars()    #flag anything between asc 128-159
    report()        #create summary report
    writefile()

    #rmsg=rmsg+eol+eol+'Result is in: ' + outid  #not currently used

    if mainsw:
        print ('Elapsed time:', format(time.perf_counter()-stime, '2.3f'),'seconds\nDone')

main()
